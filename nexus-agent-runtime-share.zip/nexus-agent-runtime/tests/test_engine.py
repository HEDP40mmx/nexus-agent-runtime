import time
import pytest
from nexus import Engine, Nexus, Registry, RetryableError, StepSpec, RunSpec, Store


def test_registered_action_completes_run(env):
    store, api, _ = env
    registry = Registry().register("echo", "1", lambda value, ctx: {"echo": value["text"], "key": ctx.effect_key})
    run_id = api.submit(RunSpec((StepSpec.action(id="a", action="echo", version="1", input={"text": "hi"}),)), "req-engine")
    engine = Engine(store, registry)
    assert engine.execute_once() is True
    run = api.get_run(run_id)
    assert run["status"] == "succeeded"
    assert run["steps"][0]["result"]["echo"] == "hi"
    assert run["steps"][0]["attempts_started"] == 1
    assert len([e for e in api.events(run_id) if e["kind"] == "step_succeeded"]) == 1


def test_unknown_action_fails_without_spending_attempt(env):
    store, api, _ = env
    run_id = api.submit(RunSpec((StepSpec.action(id="a", action="missing", version="1", input={}),)), "req-missing")
    assert Engine(store, Registry()).execute_once() is True
    run = api.get_run(run_id)
    assert run["status"] == "failed"
    assert run["steps"][0]["attempts_started"] == 0
    assert run["steps"][0]["error_code"] == "PERMANENT_ERROR"


def test_retry_delay_is_durable_and_deterministic(env):
    store, api, clock = env

    def flaky(value, ctx):
        if ctx.attempt_no == 1:
            raise RetryableError("temporary")
        return {"ok": ctx.attempt_no}

    registry = Registry().register("flaky", "1", flaky)
    step = StepSpec.action(id="a", action="flaky", version="1", input={},
                           retry=__import__("nexus").RetryPolicy(max_attempts=2, base_delay_ms=10, cap_delay_ms=15))
    run_id = api.submit(RunSpec((step,)), "req-retry")
    engine = Engine(store, registry)
    engine.execute_once()
    run = api.get_run(run_id)
    assert run["status"] == "retry_wait"
    assert run["steps"][0]["due_at_ms"] == clock.value + 10
    assert engine.execute_once() is False
    clock.value += 10
    assert engine.execute_once() is True
    assert api.get_run(run_id)["status"] == "succeeded"
    assert api.get_run(run_id)["steps"][0]["result"] == {"ok": 2}


def test_stale_owner_cannot_finish_after_epoch_replacement(env):
    store, api, clock = env
    registry = Registry().register("echo", "1", lambda value, ctx: value)
    run_id = api.submit(RunSpec((StepSpec.action(id="a", action="echo", version="1", input={}),)), "req-fence")
    first = Engine(store, registry, lease_ms=5).claim("one")
    first = Engine(store, registry, lease_ms=5).allocate_attempt(first)
    clock.value += 6
    # Reconciliation is deliberately explicit: an expired claim cannot heartbeat or finish.
    with pytest.raises(Exception) as exc:
        Engine(store, registry, lease_ms=5).heartbeat(first)
    assert exc.value.code == "LEASE_LOST"
    assert api.get_run(run_id)["status"] == "running"


def test_background_heartbeat_keeps_long_action_lease(tmp_path):
    with Store(tmp_path / "heartbeat.sqlite") as store:
        api = Nexus(store)

        def slow(value, ctx):
            time.sleep(0.15)
            return {"done": True}

        registry = Registry().register("slow", "1", slow)
        run_id = api.submit(RunSpec((StepSpec.action(id="a", action="slow", version="1", input={}),)),
                            "req-heartbeat")
        # Keep enough margin for hosted CI scheduling while remaining longer
        # than the action and therefore requiring active lease renewal.
        engine = Engine(store, registry, lease_ms=250, heartbeat_interval_ms=25)
        assert engine.execute_once() is True
        assert api.get_run(run_id)["status"] == "succeeded"
