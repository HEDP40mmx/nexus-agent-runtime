# Nexus Agent Runtime — AI handoff

This archive is a source snapshot of `HEDP40mmx/nexus-agent-runtime` at commit `86cda080ee31`. It includes the Python package, tests (including the authentic v1 SQLite migration fixture), CI workflows, and project documentation. It deliberately omits Git history, local credentials, build output, and generated package metadata.

## Project

Nexus is a single-host durable workflow runtime with SQLite-backed runs, retries, approvals, cancellation, signals, an HTTP API, CLI, supervised actions, and operator controls. Python support is `>=3.12,<3.13`; runtime dependencies are empty.

## Setup and validation

From the extracted project directory, install test dependencies with `python -m pip install -e '.[test]'`. Then run `bash scripts/check_required_files.sh`, `python -m compileall -q nexus`, and `python -m pytest -q`. The full suite passed 115 tests in a clean Python 3.12 environment at this snapshot.

## Current context and caveats

- `docs/COMPLETION_STATUS.md`, `DELIVERY_REPORT.md`, and `RESUME.md` contain useful history and known gaps, but their branch/head references may be stale. Treat the source at this archive's revision as authoritative and re-check claims against the implementation.
- The completion notes list unfinished integration and qualification work, including wiring extension brokers into runtime flows, adversarial isolation/resource tests, multi-worker and deployment qualification, and deployment documentation. Do not describe the project as production-ready based only on the passing test suite.
- Known boundaries include the trusted fallback for non-importable action handlers, kernel-dependent isolated execution, and no exactly-once guarantee for external effects. See `docs/SECURITY_MODEL.md` and `docs/COMPLETION_STATUS.md`.
- Secret references are reference-only; file references resolve only configured aliases in `SecretResolver`.

## Suggested instruction for an AI assistant

“Review this source snapshot at commit `86cda080ee31`. First inspect `docs/COMPLETION_STATUS.md` and verify its gaps against the code, tests, and current snapshot. Do not assume the project is complete or production-ready. Propose a narrowly scoped, testable next step, identify relevant files and safety constraints, and report any claims that need current validation.”
